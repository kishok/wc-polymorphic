import { SchematicsException } from '@angular-devkit/schematics';
import {
  addProjectConfiguration,
  formatFiles,
  generateFiles,
  getWorkspaceLayout,
  names,
  offsetFromRoot,
  Tree,
} from '@nrwl/devkit';
import { generateProjectLint, ProjectType, Linter } from "@nrwl/workspace";
import * as path from 'path';
import { AddLintFileOptions, LitWcGeneratorSchema } from './schema';

interface NormalizedSchema extends LitWcGeneratorSchema {
  projectName: string;
  projectRoot: string;
  projectDirectory: string;
  parsedTags: string[];
}

function normalizeOptions(
  host: Tree,
  options: LitWcGeneratorSchema
): NormalizedSchema {
  const name = names(options.name).fileName;
  const projectDirectory = options.directory
    ? `${names(options.directory).fileName}/${name}`
    : name;
  const projectName = projectDirectory.replace(new RegExp('/', 'g'), '-');
  const projectRoot = `${getWorkspaceLayout(host).libsDir}/${projectDirectory}`;
  const parsedTags = options.tags
    ? options.tags.split(',').map((s) => s.trim())
    : [];

  return {
    ...options,
    projectName,
    projectRoot,
    projectDirectory,
    parsedTags,
  };
}

function createWebComponent(host: Tree, options: NormalizedSchema) {
  const templateOptions = {
    ...options,
    ...names(options.name),
    offsetFromRoot: offsetFromRoot(options.projectRoot),
    tmpl: '',
  };
  generateFiles(
    host,
    path.join(__dirname, 'files'),
    options.projectRoot,
    templateOptions
  );
}

function addLintFiles( host:Tree, projectRoot: string,linter: Linter,options: AddLintFileOptions = {}){
  if (linter === 'eslint') {
    let configJson;
    const rootConfig = `${offsetFromRoot(projectRoot)}.eslintrc.json`;

    // Include all project files to be linted (since they are turned off in the root eslintrc file).
    const ignorePatterns = ['!**/*'];

    if (options.localConfig) {
      /**
       * The end config is much easier to reason about if "extends" comes first,
       * so as well as applying the extension from the root lint config, we also
       * adjust the config to make extends come first.
       */
      const {
        extends: extendsVal,
        ...localConfigExceptExtends
      } = options.localConfig;

      const extendsOption = extendsVal
        ? Array.isArray(extendsVal)
          ? extendsVal
          : [extendsVal]
        : [];

      configJson = {
        extends: [...extendsOption, rootConfig],
        ignorePatterns,
        ...localConfigExceptExtends,
      };
    } else {
      configJson = {
        extends: rootConfig,
        ignorePatterns,
        rules: {},
      };
    }

    host.write(
      path.join(projectRoot as any, `.eslintrc.json`),
      JSON.stringify(configJson)
    );
  }
}

export default async function (host: Tree, options: LitWcGeneratorSchema) {
  if (!options.name) {
    throw new SchematicsException(`Invalid options, "name" is required.`);
  }
  const normalizedOptions = normalizeOptions(host, options);
  addProjectConfiguration(host, normalizedOptions.projectName, {
    root: normalizedOptions.projectRoot,
    projectType: ProjectType.Library,
    sourceRoot: `${normalizedOptions.projectRoot}/`,
    targets: {
      lint: generateProjectLint(normalizedOptions.projectRoot,
        `${normalizedOptions.projectRoot}/tsconfig.json`,
        options.linter,
        [`${normalizedOptions.projectRoot}/**/*.ts`]) as any,
      build: {
        executor: `@sg/nx-lit-wc:build`,
        options: {
          tsConfig: `${normalizedOptions.projectRoot}/tsconfig.json`,
          project: `${normalizedOptions.projectRoot}/package.json`,
          entryFile: `${normalizedOptions.projectRoot}/index.ts`,
          outputPath: `dist/${normalizedOptions.projectRoot}`,
          assets: [
            {
              input: `./${normalizedOptions.projectRoot}/src`,
              glob: '**/*.!(ts)',
              output: './src',
            }
          ]
        },
      },
    },
    tags: normalizedOptions.parsedTags,
  });
  createWebComponent(host, normalizedOptions);
  addLintFiles(host,normalizedOptions.projectRoot,options.linter);
  await formatFiles(host);
  console.log(`✅️ ${normalizedOptions.projectName} created successfully !`);
}


