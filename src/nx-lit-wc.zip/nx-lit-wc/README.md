
## Description ☲
An nx-lit-wc plugin for developing Web Components using LitElement within nx workspaces.

## Installation

From your Nx workspace folder, run:

`npm i -D @sg/nx-lit-wc`

## Documentation ⚓

* Please refer the [Developer Guide](http://10.2.38.196:3001/docs/nx-plugins)