export interface LitWcGeneratorSchema {
  name: string;
  tags?: string;
  directory?: string;
  linter: Linter;
}

export interface AddLintFileOptions {
  localConfig?: any;
}